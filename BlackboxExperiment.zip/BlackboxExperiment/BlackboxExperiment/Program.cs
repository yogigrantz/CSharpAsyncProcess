﻿using System;

namespace BlackboxExperiment
{
    class Program
    {

        static void Main(string[] args)
        {
            TetstClass tc = new TetstClass();
            Console.WriteLine("Executing Asynchronous with wait in between ..... ");
            tc.ExecuteMethods();
            Console.WriteLine("End of control, but wait, Async process is going ...");
            Console.ReadLine();
        }

      
    }
}
