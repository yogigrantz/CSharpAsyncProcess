﻿using System;
using System.Threading.Tasks;
using BogusDLL1;
using BogusDLL2;

namespace BlackboxExperiment
{
    public class TetstClass
    {
        public int duration1;
        public int duration2;

        public async void ExecuteMethods()
        {
            this.duration1 = 5000;
            this.duration2 = 10000;
            Console.WriteLine("Start: " + DateTime.Now.ToString());
            await Task.Run(new Action(ExecuteMethod1));
            Console.WriteLine("First async is finished on: " + DateTime.Now.ToString());
            await Task.Run(new Action(ExecuteMethod2));
            Console.WriteLine("Second async is finished on: " + DateTime.Now.ToString());
        }


        void ExecuteMethod1()
        {
            Bogus1 dll1 = new Bogus1();
            dll1.ExecuteLongTime(duration1);
        }

        void ExecuteMethod2()
        {
            Bogus2 dll2 = new Bogus2();
            dll2.ExecuteLongTime2(duration2);
        }

    }
}
