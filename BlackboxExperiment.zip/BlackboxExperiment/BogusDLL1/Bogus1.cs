﻿using System;

namespace BogusDLL1
{
    public class Bogus1
    {
        public int ExecuteLongTime(int howManySeconds)
        {
            DateTime startTime = DateTime.Now;

            System.Threading.Thread.Sleep(howManySeconds);

            DateTime endTime = DateTime.Now;

            int timeLapse = (endTime - startTime).Seconds;

            return timeLapse;

        }
    }
}
