﻿using System;

namespace BogusDLL2
{
    public class Bogus2
    {
        public int ExecuteLongTime2(int howManySeconds)
        {
            DateTime startTime = DateTime.Now;

            System.Threading.Thread.Sleep(howManySeconds);

            DateTime endTime = DateTime.Now;

            int timeLapse = (endTime - startTime).Seconds;

            return timeLapse;

        }
    }
}
